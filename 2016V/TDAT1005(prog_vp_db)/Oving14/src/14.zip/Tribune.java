import java.io.Serializable;

/**
 * Created by qwop on 18.02.2016.
 */
public abstract class Tribune implements Serializable, Comparable<Tribune>{
    private final String tribunenavn;
    private final int kapasitet;
    private final int pris;

    public Tribune(String tribunenavn, int kapasitet, int pris) {
        this.tribunenavn = tribunenavn;
        this.kapasitet = kapasitet;
        this.pris = pris;
    }

    public String getTribunenavn() {
        return tribunenavn;
    }

    public int getKapasitet() {
        return kapasitet;
    }

    public int getPris() {
        return pris;
    }

    public abstract int finnAntallSolgteBilletter();

    public int finnInntekt() {
        return pris * finnAntallSolgteBilletter();
    }

    public abstract Billett[] kjøpBilletter(int antall);

    public abstract Billett[] kjøpBilletter(String[] navn);

    public int compareTo(Tribune trib){
        if(this == trib)return 0;
        if(this.finnInntekt() > trib.finnInntekt())return -1;
        else if(this.finnInntekt() < trib.finnInntekt())return 1;
        else return 0;
    }

    public String toString() {
        return "Tribune: " + tribunenavn + "\nKapasitet: " + kapasitet + "\nAntall solgte billetter: " + finnAntallSolgteBilletter() + "\nInntekt: " + finnInntekt();
    }

}
