import java.io.*;
import java.lang.reflect.Array;
import java.util.Arrays;

/**
 * Created by qwop on 18.02.2016.
 */
public class TribuneTest {
    public static void main(String[] args) {
        Staa staa1 = new Staa("Ståtribune 1", 120, 200);
        Staa staa2 = new Staa("Ståtribune 2", 150, 210);
        Sitte sitte1 = new Sitte("Sittetribune 1", 50, 350, 10);
        VIP vip1 = new VIP("VIP-tribune 1", 50, 500, 10, 5);

        Tribune[] tribuneTabell = new Tribune[4];
        tribuneTabell[0] = staa1;
        tribuneTabell[1] = staa2;
        tribuneTabell[2] = sitte1;
        tribuneTabell[3] = vip1;

        String[] navn = {"Ole", "Magnus", "Even", "Mosafa"};

        Billett[] billett1 = staa1.kjøpBilletter(1);
        Billett[] billett2 = staa2.kjøpBilletter(2);
        Billett[] billett3 = sitte1.kjøpBilletter(3);
        Billett[] billett4 = vip1.kjøpBilletter(navn);

        for (int i = 0; i < billett1.length; i++) {
            System.out.println(billett1[i]);
        }

        for (int i = 0; i < billett2.length; i++) {
            System.out.println(billett2[i]);
        }

        for (int i = 0; i < billett3.length; i++) {
            System.out.println(billett3[i]);
        }

        for (int i = 0; i < billett4.length; i++) {
            System.out.println(billett4[i]);
        }

        System.out.println();

        System.out.println("--------");
        System.out.println(staa1);
        System.out.println("--------");
        System.out.println(staa2);
        System.out.println("--------");
        System.out.println(sitte1);
        System.out.println("--------");
        System.out.println(vip1);
        System.out.println("--------");

        System.out.println();

        Arrays.sort(tribuneTabell);

        for (int i = 0; i < tribuneTabell.length; i++) {
            System.out.println(tribuneTabell[i]);
        }
    }

    public static boolean lesTilFil(Tribune[] trib, String filnavn){
        try {
            ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(filnavn));
            stream.writeObject(trib);
            stream.close();
        }
        catch (Exception e){
            System.err.println("Feil oppstått");
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static Tribune[] lesFraFil(String filnavn){
        Tribune[] trib = null;
        try{
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream(filnavn));
            trib = (Tribune[])stream.readObject();
            stream.close();
        }
        catch (Exception e){
            System.err.println("Feil oppstått");
            e.printStackTrace();
        }
        return trib;
    }
}
