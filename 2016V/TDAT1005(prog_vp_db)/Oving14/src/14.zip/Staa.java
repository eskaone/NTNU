/**
 * Created by qwop on 18.02.2016.
 */
public class Staa extends Tribune {
    private int antSolgteBilletter = 0;

    public Staa(String tribunenavn, int kapasitet, int pris) {
        super(tribunenavn, kapasitet, pris);
    }

    public int getAntSolgteBilletter() {
        return antSolgteBilletter;
    }

    public int finnAntallSolgteBilletter() {
        return getAntSolgteBilletter();
    }

    @Override
    public Billett[] kjøpBilletter(int antall) {
        StaaplassBillett[] billetter = new StaaplassBillett[antall];
        for (int i = 0; i < billetter.length; i++) {
            if (getKapasitet() - antSolgteBilletter >= 0) {
                billetter[i] = new StaaplassBillett(getTribunenavn(), getPris());
                antSolgteBilletter++;
            } else {
                return null;
            }
        }
        return billetter;
    }

    @Override
    public Billett[] kjøpBilletter(String[] navn) {
        Billett[] billetter = new Billett[navn.length];
        for (int i = 0; i < billetter.length; i++) {
            if (getKapasitet() - antSolgteBilletter >= 0) {
                billetter[i] = new StaaplassBillett(getTribunenavn(), getPris());
                antSolgteBilletter++;
            } else {
                return null;
            }
        }
        return billetter;
    }
}
