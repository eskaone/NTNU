/**
 * Created by qwop on 18.02.2016.
 */
public class VIP extends Tribune {
    private String[][] tilskuer; // tabellstørrelse: antall rader * antall plasser pr rad

    public VIP(String tribunenavn, int kapasitet, int pris, int rader, int plassPrRad) {
        super(tribunenavn, kapasitet, pris);
        tilskuer = new String[rader][plassPrRad];
    }

    public String[][] getTilskuer() {
        return tilskuer;
    }

    public int finnAntallSolgteBilletter() {
        int teller = 0;
        for(int i = 0; i < tilskuer.length; i++) {
            for (int j = 0; j < tilskuer[i].length; j++) {
                if (tilskuer[i][j] != null) {
                    teller++;
                }
            }
        }
        return teller;
    }

    @Override
    public Billett[] kjøpBilletter(int antall) {
        return null;
    }

    @Override
    public Billett[] kjøpBilletter(String[] navn) {
        Billett[] billetter = new Billett[navn.length];
        int[] hoi = finnLedig(navn.length);
        for (int i = 0; i < billetter.length; i++) {
            if (getKapasitet() - finnAntallSolgteBilletter() >= 0 && billetter[i] == null) {
                billetter[i] = new SitteplassBillett(getTribunenavn(), getPris(), hoi[0], hoi[1]);
                tilskuer[hoi[0]][hoi[1]] = navn[i];
                hoi[1]++;
            } else {
                return null;
            }
        }
        return billetter;
    }

    private int[] finnLedig(int antall) {
        int[] tab = new int[2];
        int teller = 0;
        for(int i = 0; i < tilskuer.length; i++) {
            teller = 0;
            for (int j = 0; j < tilskuer[i].length; j++) {
                if (tilskuer[i][j] == null) {
                    teller++;
                    if (teller >= antall) {
                        tab[0] = i;
                        tab[1] = j - antall + 1;
                        return tab;
                    }
                }
            }
        }
        return null;
    }
}
