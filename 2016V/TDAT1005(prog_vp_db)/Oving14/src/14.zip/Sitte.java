/**
 * Created by qwop on 18.02.2016.
 */
public class Sitte extends Tribune {
    private int[] antOpptatt;  // tabellstørrelse: antall rader
    private int rader;

    public Sitte(String tribunenavn, int kapasitet, int pris, int rader) {
        super(tribunenavn, kapasitet, pris);
        antOpptatt = new int[rader];
        this.rader = rader;
    }

    public int[] getAntOpptatt() {
        return antOpptatt;
    }

    public int finnAntallSolgteBilletter() {
        int teller = 0;
        for(int i = 0; i < antOpptatt.length; i++) {
            teller += antOpptatt[i];
        }
        return teller;
    }

    private int finnLedigRad(int antall) {
        for (int i = 0; i < antOpptatt.length; i++) {
            if ((getKapasitet() / rader) > antall) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public Billett[] kjøpBilletter(int antall) {
        Billett[] billetter = new Billett[antall];
        int rad = finnLedigRad(antall);
        if (rad < 0) {
            return null;
        }
        for (int i = 0; i < billetter.length; i++) {
            if (getKapasitet() - finnAntallSolgteBilletter() >= 0) {
                billetter[i] = new SitteplassBillett(getTribunenavn(), getPris(), rad, antOpptatt[rad]);
                antOpptatt[rad]++;
            } else {
                return null;
            }
        }
        return billetter;
    }

    @Override
    public Billett[] kjøpBilletter(String[] navn) {
        Billett[] billetter = new Billett[navn.length];
        int rad = finnLedigRad(navn.length);
        for (int i = 0; i < billetter.length; i++) {
            if (getKapasitet() - finnAntallSolgteBilletter() >= 0) {
                billetter[i] = new SitteplassBillett(getTribunenavn(), getPris(), finnLedigRad(navn.length), antOpptatt[rad]);
                antOpptatt[rad]++;
            } else {
                return null;
            }
        }
        return billetter;
    }
}
